#!/usr/bin/env python3
"""
convert_to_parquet.py
Streams 479 GB users_data.json directly into compressed Apache Parquet files.
Uses DuckDB C++ SIMD vector engine to maximize disk & CPU throughput.
Generated Parquet files are immediately available for instant search in the API!
"""

import os
import sys
import time
import glob
import duckdb
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, "..", ".env"))

_default_json = os.path.normpath(os.path.join(BASE_DIR, "..", "users_data.json"))
_default_parquet = os.path.normpath(os.path.join(BASE_DIR, "..", "parquet"))
JSON_PATH   = (os.environ.get("JSON_PATH") or (r"F:/hitek/users_data/users_data.json" if os.path.exists(r"F:/hitek/users_data/users_data.json") else _default_json)).replace("\\", "/")
PARQUET_DIR = (os.environ.get("PARQUET_DIR") or (r"F:/hitek/users_data/parquet" if os.path.exists(r"F:/hitek/users_data/parquet") else _default_parquet)).replace("\\", "/")

def main():
    os.makedirs(PARQUET_DIR, exist_ok=True)
    fsize = os.path.getsize(JSON_PATH) if os.path.exists(JSON_PATH) else 0
    print("=" * 65)
    print("       HIGH-SPEED JSON -> PARQUET CONVERTER")
    print("=" * 65)
    print(f"Source JSON    : {JSON_PATH} ({fsize/1e9:.1f} GB)")
    print(f"Output Parquet : {PARQUET_DIR}")
    
    existing = glob.glob(f"{PARQUET_DIR}/*.parquet")
    print(f"Existing files : {len(existing)} Parquet file(s)")
    print("-" * 65)

    con = duckdb.connect()
    # Configure high performance memory & threading
    con.execute("SET max_memory='16GB';")
    con.execute("SET preserve_insertion_order=false;")
    con.execute("SET threads=4;")

    print("[*] Starting C++ streaming conversion...")
    print("[*] Splitting into compressed ~1 GB Parquet files (SNAPPY)...")
    print("[*] Search API can query existing files concurrently with NO locks!")
    print("-" * 65)

    t0 = time.time()
    
    # We query the JSON array directly using DuckDB C++ parser
    # and write to partitioned Parquet files of ~1GB each (1,073,741,824 bytes)
    # with row group size 100,000 for fast predicate pushdown
    sql = f"""
    COPY (
        SELECT 
            _id['$oid']::VARCHAR as oid,
            mobile::VARCHAR as mobile,
            name::VARCHAR as name,
            fname::VARCHAR as fname,
            address::VARCHAR as address,
            alt::VARCHAR as alt,
            circle::VARCHAR as circle,
            id::VARCHAR as doc_id,
            email::VARCHAR as email
        FROM read_json_auto(
            '{JSON_PATH}', 
            maximum_object_size=67108864
        )
    ) TO '{PARQUET_DIR}' 
    (
        FORMAT PARQUET, 
        COMPRESSION 'SNAPPY', 
        ROW_GROUP_SIZE 100000, 
        FILE_SIZE_BYTES 1073741824,
        OVERWRITE TRUE
    );
    """
    
    try:
        con.execute(sql)
        elapsed = time.time() - t0
        print(f"[+] Conversion complete in {elapsed/60:.2f} minutes!")
    except Exception as e:
        print(f"[!] Importer status: {e}")

    files = glob.glob(f"{PARQUET_DIR}/*.parquet")
    total_bytes = sum(os.path.getsize(f) for f in files)
    print(f"[+] Total Parquet files: {len(files)}")
    print(f"[+] Total Parquet size : {total_bytes/1e9:.2f} GB")
    
    if files:
        count = con.execute(f"SELECT COUNT(*) FROM read_parquet('{PARQUET_DIR}/*.parquet')").fetchone()[0]
        print(f"[+] Total Records Ready: {count:,}")
    con.close()

if __name__ == "__main__":
    main()
