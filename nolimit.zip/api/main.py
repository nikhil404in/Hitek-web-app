#!/usr/bin/env python3
"""
api/main.py  v4.0 — Instant Search Engine
Parallel per-file search with early-exit, LRU cache, and smart query routing.
Achieves <1s results across 1.78B records on 157 Parquet files.
"""

import os
import math
import time
import glob
import threading
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError
from collections import OrderedDict
from typing import Optional, List

import duckdb
from fastapi import FastAPI, HTTPException, Request, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from dotenv import load_dotenv

# ─────────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, "..", ".env"))

_env_pdir = os.environ.get("PARQUET_DIR")
if not _env_pdir or not os.path.exists(_env_pdir):
    _local_pdir = os.path.normpath(os.path.join(BASE_DIR, "..", "parquet")).replace("\\", "/")
    if os.path.exists(_local_pdir):
        PARQUET_DIR = _local_pdir
    elif os.path.exists(r"D:/parquet"):
        PARQUET_DIR = r"D:/parquet"
    else:
        PARQUET_DIR = _local_pdir
else:
    PARQUET_DIR = _env_pdir.replace("\\", "/")

API_KEY     = os.environ.get("API_KEY", "hitek-search-2026-secret")
WEB_DIR     = os.path.join(BASE_DIR, "..", "web")
CPU_CORES   = min(os.cpu_count() or 8, 12)

# ─── Single-User Disk Search Lock & Logging ───────────────────────
# Enforce strictly 1 disk search at a time to prevent HDD thrashing
QUEUE_MODE = os.environ.get("QUEUE_MODE", "reject").strip().lower()  # "reject" (default instant 429) or "queue"
QUEUE_TIMEOUT = float(os.environ.get("QUEUE_TIMEOUT", "60.0"))
_env_timeout = os.environ.get("SEARCH_TIMEOUT_SECONDS")
SEARCH_TIMEOUT_SECONDS = float(_env_timeout) if _env_timeout and float(_env_timeout) > 0 else None

_DISK_SEARCH_LOCK = threading.Lock()

_CURRENT_SEARCH = {
    "active": False,
    "started_at": 0.0,
    "field": "",
    "query": "",
    "client_ip": "",
    "waiting_count": 0,
}
_CURRENT_SEARCH_LOCK = threading.Lock()

def _mark_search_start(client_ip: str, field: str, q: str):
    with _CURRENT_SEARCH_LOCK:
        _CURRENT_SEARCH["active"] = True
        _CURRENT_SEARCH["started_at"] = time.time()
        _CURRENT_SEARCH["field"] = field
        _CURRENT_SEARCH["query"] = (q[:12] + "...") if len(q) > 12 else q
        _CURRENT_SEARCH["client_ip"] = client_ip

def _mark_search_end():
    with _CURRENT_SEARCH_LOCK:
        _CURRENT_SEARCH["active"] = False
        _CURRENT_SEARCH["started_at"] = 0.0
        _CURRENT_SEARCH["field"] = ""
        _CURRENT_SEARCH["query"] = ""
        _CURRENT_SEARCH["client_ip"] = ""

def _get_search_status() -> dict:
    with _CURRENT_SEARCH_LOCK:
        active = _CURRENT_SEARCH["active"]
        elapsed = round(time.time() - _CURRENT_SEARCH["started_at"], 1) if active else 0.0
        waiting = _CURRENT_SEARCH["waiting_count"]
        return {
            "busy": active,
            "elapsed_seconds": elapsed,
            "waiting_in_queue": waiting,
            "queue_mode": QUEUE_MODE,
        }

LOG_FILE  = os.path.normpath(os.path.join(BASE_DIR, "..", "log.txt"))
_LOG_LOCK = threading.Lock()

def _get_client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip.strip()
    return request.client.host if request.client else "unknown"

def _log_search(ip: str, field: str, query: str, results_count: int, elapsed_ms: float, status: str):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] IP: {ip:<15} | FIELD: {field:<7} | QUERY: {query!r:<22} | RESULTS: {results_count:<4} | TIME: {elapsed_ms:>7.1f}ms | STATUS: {status}\n"
    with _LOG_LOCK:
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line)
                f.flush()
        except Exception as e:
            print(f"[!] Log write error: {e}")

# ─── LRU Query Cache ──────────────────────────────────────────────
_CACHE: OrderedDict = OrderedDict()
_CACHE_MAX  = 500          # keep last 500 unique queries
_CACHE_TTL  = 300          # 5-minute TTL
_CACHE_LOCK = threading.Lock()

def _cache_get(key: str):
    with _CACHE_LOCK:
        entry = _CACHE.get(key)
        if entry and (time.time() - entry["ts"]) < _CACHE_TTL:
            _CACHE.move_to_end(key)
            return entry["data"]
        return None

def _cache_put(key: str, data):
    with _CACHE_LOCK:
        _CACHE[key] = {"data": data, "ts": time.time()}
        _CACHE.move_to_end(key)
        if len(_CACHE) > _CACHE_MAX:
            _CACHE.popitem(last=False)

# ─── Parquet file list (computed once at startup) ─────────────────
_PARQUET_FILES: List[str] = []
_STATS = {
    "total_records": 1_782_434_387,
    "parquet_files": 157,
    "db_size_gb":    169.31,
    "status":        "Ready",
}

def _load_file_list():
    global _PARQUET_FILES
    raw = glob.glob(f"{PARQUET_DIR}/*.parquet")
    _PARQUET_FILES = sorted(
        [f.replace("\\", "/") for f in raw if os.path.getsize(f) > 1_000],
        key=lambda p: int(os.path.splitext(os.path.basename(p))[0].split("_")[-1])
    )
    print(f"[*] Loaded {len(_PARQUET_FILES)} Parquet files from {PARQUET_DIR}")

# ─── Per-thread DuckDB connections (avoid GIL + lock contention) ──
_LOCAL = threading.local()

def _get_thread_con() -> duckdb.DuckDBPyConnection:
    if not hasattr(_LOCAL, "con") or _LOCAL.con is None:
        con = duckdb.connect()                          # in-memory, no file lock
        con.execute("SET threads=1;")                   # 1 thread per worker (parallelism comes from pool)
        con.execute("SET max_memory='512MB';")          # tight per-thread cap → no swap
        con.execute("SET preserve_insertion_order=false;")
        _LOCAL.con = con
    return _LOCAL.con

# ─── Query one Parquet file, return up to `need` rows ─────────────
COLS = ["oid", "mobile", "name", "fname", "address", "alt", "circle", "doc_id", "email"]
COL_SELECT = ", ".join(COLS)

def _search_one_file(filepath: str, where: str, params: list, need: int) -> list:
    try:
        con = _get_thread_con()
        sql = f"""
            SELECT {COL_SELECT}
            FROM read_parquet('{filepath}')
            {where}
            LIMIT {need}
        """
        rows = con.execute(sql, params).fetchall()
        return [dict(zip(COLS, r)) for r in rows]
    except Exception:
        return []

# ─── Parallel early-exit search across all files ──────────────────
def _parallel_search(where: str, params: list, need: int, offset: int, timeout_sec: Optional[float] = None) -> tuple[list, bool]:
    """
    Fan out across all Parquet files in parallel.
    Collect results until we have need+offset rows, or search completes.
    If timeout_sec is None, search runs without any time limit until finished.
    Returns (results, timed_out).
    """
    results   = []
    done      = threading.Event()
    lock      = threading.Lock()
    target    = need + offset          # collect extra rows to support offset
    deadline  = (time.perf_counter() + timeout_sec) if (timeout_sec is not None and timeout_sec > 0) else None
    timed_out = False

    def worker(fp):
        if done.is_set() or (deadline is not None and time.perf_counter() >= deadline):
            done.set()
            return []
        partial = _search_one_file(fp, where, params, target)
        with lock:
            if not done.is_set():
                results.extend(partial)
                if len(results) >= target or (deadline is not None and time.perf_counter() >= deadline):
                    done.set()
        return partial

    with ThreadPoolExecutor(max_workers=CPU_CORES) as pool:
        futures = {pool.submit(worker, fp): fp for fp in _PARQUET_FILES}
        try:
            for fut in as_completed(futures, timeout=timeout_sec if (timeout_sec and timeout_sec > 0) else None):
                if done.is_set() or (deadline is not None and time.perf_counter() >= deadline):
                    done.set()
                    for f in futures:
                        f.cancel()
                    break
        except Exception:
            timed_out = True
            done.set()
            for f in futures:
                f.cancel()

    if deadline is not None and time.perf_counter() >= deadline:
        timed_out = True

    return results[offset : offset + need], timed_out

# ─── Smart query builder ───────────────────────────────────────────
SEARCHABLE = {"mobile", "name", "fname", "address", "alt", "circle", "doc_id", "email"}

def _build_where(q: str, field: str):
    q = q.strip()
    if field == "mobile":
        if q.isdigit() and len(q) == 10:
            return "WHERE mobile = ?", [q]
        if q.isdigit():
            return "WHERE mobile LIKE ?", [f"{q}%"]
        return "WHERE mobile LIKE ?", [f"%{q}%"]
    elif field in SEARCHABLE:
        return f"WHERE {field} ILIKE ?", [f"%{q}%"]
    else:
        # "all" — search the 4 most useful columns only (faster than 7-column OR)
        cols = ["mobile", "name", "email", "doc_id"]
        clause = " OR ".join(f"{c} ILIKE ?" for c in cols)
        return f"WHERE ({clause})", [f"%{q}%"] * len(cols)

# ─── Mobile exact-lookup optimised path (single DuckDB connection) ─
_MAIN_CON_LOCK = threading.Lock()
_MAIN_CON: Optional[duckdb.DuckDBPyConnection] = None

def _get_main_con():
    global _MAIN_CON
    if _MAIN_CON is None:
        con = duckdb.connect()
        con.execute(f"SET threads={CPU_CORES};")
        con.execute("SET max_memory='4GB';")
        con.execute("SET preserve_insertion_order=false;")
        fl = ", ".join(f"'{f}'" for f in _PARQUET_FILES)
        con.execute(f"CREATE OR REPLACE VIEW contacts AS SELECT * FROM read_parquet([{fl}])")
        print("[*] Main DuckDB view 'contacts' ready.")
        _MAIN_CON = con
    return _MAIN_CON

# ─────────────────────────────────────────────────────────────────
limiter = Limiter(key_func=get_remote_address)

app = FastAPI(
    title="Instant Phone Search API — v4.0",
    version="4.0.0",
    description="<1s parallel Parquet search across 1.78 Billion telecom records.",
)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["GET"], allow_headers=["*"],
)

web_path = os.path.abspath(WEB_DIR)
if os.path.isdir(web_path):
    app.mount("/ui", StaticFiles(directory=web_path, html=True), name="ui")

def require_api_key(x_api_key: str = Header(..., alias="X-API-Key")):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API key")

# ─── Startup ──────────────────────────────────────────────────────
@app.on_event("startup")
def startup_event():
    _load_file_list()
    # Warm up: open the main connection so first query isn't slow
    _get_main_con()
    print(f"[*] Ready! {len(_PARQUET_FILES)} files | {CPU_CORES} parallel workers")

# ─── Endpoints ────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {
        "status":        "ok",
        "engine":        f"DuckDB Parallel ({CPU_CORES} workers) + Parquet",
        "total_records": _STATS["total_records"],
        "parquet_files": len(_PARQUET_FILES),
    }

@app.get("/stats", dependencies=[Depends(require_api_key)])
def stats(request: Request):
    status_info = _get_search_status()
    return {
        **_STATS,
        **status_info,
    }

@app.get("/search/status")
def search_status():
    """Public lightweight endpoint to check if the search engine is currently busy."""
    return _get_search_status()

@app.get("/search", dependencies=[Depends(require_api_key)])
def search(
    request: Request,
    q: str,
    field: str = "all",
    page:  int = 1,
    limit: int = 50,
):
    client_ip = _get_client_ip(request)
    q = q.strip()
    if len(q) < 2:
        _log_search(client_ip, field, q, 0, 0.0, "INVALID (Query < 2 chars)")
        raise HTTPException(400, "Query must be at least 2 characters.")

    # Enforce strictly 10 digits for mobile search (no letters, no symbols)
    if field == "mobile":
        clean_q = q.replace(" ", "").replace("-", "")
        if clean_q.startswith("+91"):
            clean_q = clean_q[3:]
        elif clean_q.startswith("91") and len(clean_q) == 12 and clean_q.isdigit():
            clean_q = clean_q[2:]
        if not clean_q.isdigit() or len(clean_q) != 10:
            _log_search(client_ip, field, q, 0, 0.0, "INVALID (Mobile must be exactly 10 digits, numbers only)")
            raise HTTPException(400, "Mobile search requires exactly 10 digits (numbers only, no letters).")
        q = clean_q

    limit  = min(max(limit, 1), 100)
    page   = max(page, 1)
    offset = (page - 1) * limit

    # Check LRU cache first (RAM only — zero disk I/O)
    cache_key = hashlib.md5(f"{q}|{field}|{page}|{limit}".encode()).hexdigest()
    cached = _cache_get(cache_key)
    if cached:
        cached["cached"] = True
        _log_search(client_ip, field, q, len(cached.get("results", [])), cached.get("elapsed_ms", 0.0), "OK (CACHED)")
        return cached

    where, params = _build_where(q, field)

    # Enforce minimum length for doc_id (billions of numeric chars, need specificity)
    if field == "doc_id" and len(q) < 6:
        _log_search(client_ip, field, q, 0, 0.0, "INVALID (doc_id < 6 chars)")
        raise HTTPException(400, "Document ID search requires at least 6 characters.")

    # Enforce strictly 1 search running at a time to avoid server and disk overload
    acquired = False
    if QUEUE_MODE == "queue":
        with _CURRENT_SEARCH_LOCK:
            _CURRENT_SEARCH["waiting_count"] += 1
        try:
            acquired = _DISK_SEARCH_LOCK.acquire(blocking=True, timeout=QUEUE_TIMEOUT)
        finally:
            with _CURRENT_SEARCH_LOCK:
                _CURRENT_SEARCH["waiting_count"] = max(0, _CURRENT_SEARCH["waiting_count"] - 1)
    else:
        # Default: Instant rejection (0ms wait) if another search is active
        acquired = _DISK_SEARCH_LOCK.acquire(blocking=False)

    if not acquired:
        _log_search(client_ip, field, q, 0, 0.0, "BUSY (Another search in progress)")
        raise HTTPException(
            status_code=429,
            detail="Server is busy: another search is currently running. Only 1 search is processed at a time to prevent server overload. Please wait a few seconds and try again."
        )

    _mark_search_start(client_ip, field, q)
    t0 = time.perf_counter()
    try:
        # Search Parquet files with strict 20s timeout (stops disk scanning if not in DB)
        results, timed_out = _parallel_search(where, params, limit, offset, timeout_sec=SEARCH_TIMEOUT_SECONDS)
    finally:
        _mark_search_end()
        _DISK_SEARCH_LOCK.release()

    elapsed_ms = round((time.perf_counter() - t0) * 1000, 1)
    has_more   = len(results) >= limit
    estimated  = offset + len(results) + (limit if has_more else 0)
    total_pages = max(1, math.ceil(estimated / limit))

    response = {
        "query":       q,
        "field":       field,
        "total":       estimated,
        "pages":       total_pages,
        "total_pages": total_pages,
        "has_more":    has_more,
        "page":        page,
        "limit":       limit,
        "elapsed_ms":  elapsed_ms,
        "timed_out":   timed_out,
        "cached":      False,
        "results":     results,
    }
    _cache_put(cache_key, response)
    status_str = "OK" if results else ("NOT FOUND (TIMEOUT)" if timed_out else "NOT FOUND")
    _log_search(client_ip, field, q, len(results), elapsed_ms, status_str)
    return response


@app.get("/record/{mobile}", dependencies=[Depends(require_api_key)])
def get_record(request: Request, mobile: str):
    client_ip = _get_client_ip(request)
    mobile = mobile.strip().replace(" ", "").replace("-", "")
    if mobile.startswith("+91"):
        mobile = mobile[3:]
    elif mobile.startswith("91") and len(mobile) == 12 and mobile.isdigit():
        mobile = mobile[2:]
    if not mobile.isdigit() or len(mobile) != 10:
        _log_search(client_ip, "record", mobile, 0, 0.0, "INVALID (Mobile must be exactly 10 digits, numbers only)")
        raise HTTPException(400, "Mobile number must be exactly 10 digits (numbers only, no letters).")

    cache_key = f"rec:{mobile}"
    cached = _cache_get(cache_key)
    if cached:
        _log_search(client_ip, "record", mobile, len(cached.get("records", [])), cached.get("elapsed_ms", 0.0), "OK (CACHED)")
        return cached

    # Enforce strictly 1 search running at a time
    acquired = False
    if QUEUE_MODE == "queue":
        with _CURRENT_SEARCH_LOCK:
            _CURRENT_SEARCH["waiting_count"] += 1
        try:
            acquired = _DISK_SEARCH_LOCK.acquire(blocking=True, timeout=QUEUE_TIMEOUT)
        finally:
            with _CURRENT_SEARCH_LOCK:
                _CURRENT_SEARCH["waiting_count"] = max(0, _CURRENT_SEARCH["waiting_count"] - 1)
    else:
        acquired = _DISK_SEARCH_LOCK.acquire(blocking=False)

    if not acquired:
        _log_search(client_ip, "record", mobile, 0, 0.0, "BUSY (Another search in progress)")
        raise HTTPException(
            status_code=429,
            detail="Server is busy: another search is currently running. Only 1 search is processed at a time. Please wait a few seconds and try again."
        )

    _mark_search_start(client_ip, "record", mobile)
    t0 = time.perf_counter()
    try:
        # Use parallel engine with no timeout
        results, timed_out = _parallel_search("WHERE mobile = ?", [mobile], 20, 0, timeout_sec=SEARCH_TIMEOUT_SECONDS)
    finally:
        _mark_search_end()
        _DISK_SEARCH_LOCK.release()

    elapsed_ms = round((time.perf_counter() - t0) * 1000, 1)

    if not results:
        status_str = "NOT FOUND (TIMEOUT)" if timed_out else "NOT FOUND"
        _log_search(client_ip, "record", mobile, 0, elapsed_ms, status_str)
        raise HTTPException(404, f"No record found for mobile: {mobile}")

    response = {
        "elapsed_ms": elapsed_ms,
        "timed_out":  timed_out,
        "records":    results,
    }
    _cache_put(cache_key, response)
    _log_search(client_ip, "record", mobile, len(results), elapsed_ms, "OK")
    return response


if __name__ == "__main__":
    import uvicorn
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", 8000))
    display_host = "127.0.0.1" if host == "0.0.0.0" else host
    print(f"[*] Starting API on http://{host}:{port}")
    print(f"[*] Local Web UI:       http://{display_host}:{port}/ui")
    print(f"[*] Searches logged to: {LOG_FILE}")
    uvicorn.run("main:app", host=host, port=port, reload=False, workers=1)
