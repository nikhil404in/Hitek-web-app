
/* app.js - Instant Search Frontend for Parquet Engine */
'use strict';

const API_BASE  = window.location.origin;
const KEY_STORE = 'hitek_api_key_parquet';

let currentPage  = 1;
let currentQuery = '';
let currentField = 'mobile';
let lastResults  = [];

// DOM elements
const searchInput    = document.getElementById('searchInput');
const fieldSelect    = document.getElementById('fieldSelect');
const searchBtn      = document.getElementById('searchBtn');
const resultsSection = document.getElementById('results-section');
const resultsBody    = document.getElementById('results-body');
const metaCount      = document.getElementById('meta-count');
const metaLatency    = document.getElementById('meta-latency');
const paginationEl   = document.getElementById('pagination');
const emptyState     = document.getElementById('empty-state');
const emptyTitle     = document.getElementById('empty-title');
const emptyDesc      = document.getElementById('empty-desc');
const busyState      = document.getElementById('busy-state');
const busyText       = document.getElementById('busy-text');
const retryBtn       = document.getElementById('retryBtn');
const welcomeState   = document.getElementById('welcome-state');
const loader         = document.getElementById('loader');
const statsBadge     = document.getElementById('stats-badge');
const exportBtn      = document.getElementById('exportBtn');
const apiKeyInput    = document.getElementById('apiKeyInput');
const saveKeyBtn     = document.getElementById('saveKeyBtn');
const modalOverlay   = document.getElementById('modal-overlay');
const closeModal     = document.getElementById('closeModal');
const modalTable     = document.getElementById('modal-table');

// API Key handling
function getKey() {
  return localStorage.getItem(KEY_STORE) || 'hitek-search-2026-secret';
}
apiKeyInput.value = getKey();

saveKeyBtn.addEventListener('click', () => {
  localStorage.setItem(KEY_STORE, apiKeyInput.value.trim());
  saveKeyBtn.textContent = 'Saved!';
  setTimeout(() => saveKeyBtn.textContent = 'Save', 1500);
  loadStats();
});

function headers() {
  return { 'X-API-Key': getKey() };
}

// Live stats polling
async function loadStats() {
  try {
    const r = await fetch(`${API_BASE}/stats`, { headers: headers() });
    if (!r.ok) {
      statsBadge.innerHTML = '<span class="pulse-dot" style="background:#ef4444"></span> Auth Required';
      return;
    }
    const d = await r.json();
    if (d.busy) {
      statsBadge.innerHTML = `
        <span class="pulse-dot pulse-warning"></span> 
        <span style="color:#f59e0b;font-weight:600">Search In Progress</span> &middot; ${d.total_records.toLocaleString()} records
      `;
    } else {
      statsBadge.innerHTML = `
        <span class="pulse-dot"></span> 
        ${d.total_records.toLocaleString()} records &middot; ${d.db_size_gb} GB Parquet
      `;
    }
  } catch(e) {
    statsBadge.innerHTML = '<span class="pulse-dot" style="background:#f59e0b"></span> API Offline';
  }
}
loadStats();
setInterval(loadStats, 5000);

const clearBtn      = document.getElementById('clearBtn');

// Field selector helper (fixed to phone search)
window.setField = function() {
  currentField = 'mobile';
  searchInput.focus();
};

// Enforce strictly 10 digits only: NO letters (no abcd), NO symbols
searchInput.addEventListener('input', () => {
  let cleaned = searchInput.value.replace(/\D/g, '').slice(0, 10);
  if (searchInput.value !== cleaned) {
    searchInput.value = cleaned;
  }
  if (clearBtn) {
    if (cleaned.length > 0) {
      clearBtn.classList.remove('hidden');
    } else {
      clearBtn.classList.add('hidden');
    }
  }
});

// Block any non-digit keys on keydown
searchInput.addEventListener('keydown', (e) => {
  // Allow control/navigation keys
  if (
    ['Backspace', 'Tab', 'Delete', 'ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key) ||
    e.ctrlKey || e.metaKey
  ) {
    if (e.key === 'Enter') doSearch(1);
    return;
  }
  if (e.key === 'Enter') {
    doSearch(1);
    return;
  }
  // Block letters (a-z, A-Z) and symbols
  if (!/^[0-9]$/.test(e.key)) {
    e.preventDefault();
    return;
  }
  // Disallow more than 10 digits if text is not selected
  if (searchInput.value.length >= 10 && searchInput.selectionStart === searchInput.selectionEnd) {
    e.preventDefault();
  }
});

// Clean pasted text: keep only first 10 digits
searchInput.addEventListener('paste', (e) => {
  e.preventDefault();
  const pasteText = (e.clipboardData || window.clipboardData).getData('text') || '';
  let digits = pasteText.replace(/\D/g, '');
  if (digits.startsWith('91') && digits.length === 12) {
    digits = digits.slice(2);
  }
  digits = digits.slice(0, 10);
  searchInput.value = digits;
  if (clearBtn) {
    if (digits.length > 0) {
      clearBtn.classList.remove('hidden');
    } else {
      clearBtn.classList.add('hidden');
    }
  }
});

if (clearBtn) {
  clearBtn.addEventListener('click', () => {
    searchInput.value = '';
    clearBtn.classList.add('hidden');
    searchInput.focus();
  });
}

// Search trigger
searchBtn.addEventListener('click', () => doSearch(1));

async function doSearch(page) {
  // Strictly enforce 10-digit mobile number only
  let q = searchInput.value.trim().replace(/\D/g, '');
  if (q.startsWith('91') && q.length === 12) {
    q = q.slice(2);
  }
  q = q.slice(0, 10);

  if (!q) {
    searchInput.focus();
    return;
  }

  if (q.length !== 10) {
    alert('Please enter a valid 10-digit mobile number (numbers only, no letters).');
    searchInput.focus();
    return;
  }

  currentQuery = q;
  currentField = 'mobile';
  currentPage  = page;

  hideAllStates();
  loader.classList.remove('hidden');
  searchBtn.disabled = true;

  try {
    const params = new URLSearchParams({
      q: currentQuery,
      field: currentField,
      page: currentPage,
      limit: 50
    });

    const r = await fetch(`${API_BASE}/search?${params}`, { headers: headers() });

    if (r.status === 429) {
      const err = await r.json().catch(() => ({ detail: "Server is busy: another search is currently running. Only 1 search is processed at a time to prevent server overload." }));
      loader.classList.add('hidden');
      searchBtn.disabled = false;
      showBusyState(err.detail);
      return;
    }

    if (!r.ok) {
      const err = await r.json().catch(() => ({ detail: r.statusText }));
      alert('Search Error: ' + (err.detail || r.statusText));
      loader.classList.add('hidden');
      return;
    }

    // Success: hide busy state if visible, show results
    busyState.classList.add('hidden');
    const data = await r.json();
    lastResults = data.results;
    renderResults(data);
  } catch(e) {
    alert('Could not reach API server. Is it running?\n\n' + e.message);
  } finally {
    loader.classList.add('hidden');
    searchBtn.disabled = false;
  }
}

let _busyCountdownTimer = null;

function showBusyState(errorMessage) {
  hideAllStates();
  busyState.classList.remove('hidden');

  let attemptsLeft = 5;
  let secondsLeft  = 4;

  const msg = errorMessage || "Another search is currently in progress. Only <strong>1 search runs at a time</strong> to protect server performance and avoid load.";

  function updateCountdown() {
    busyText.innerHTML = `${msg}<br>
      <div style="margin-top:12px;">
        <span class="busy-countdown">Auto-checking server in <strong>${secondsLeft}s</strong>… (${attemptsLeft} check${attemptsLeft !== 1 ? 's' : ''} left)</span>
      </div>`;
  }
  updateCountdown();

  if (_busyCountdownTimer) {
    clearInterval(_busyCountdownTimer);
  }

  _busyCountdownTimer = setInterval(async () => {
    secondsLeft--;
    if (secondsLeft <= 0) {
      secondsLeft = 4;
      attemptsLeft--;
      if (attemptsLeft < 0) {
        clearInterval(_busyCountdownTimer);
        _busyCountdownTimer = null;
        busyText.innerHTML = `${msg}<br><br><span style="color:#fde047;font-weight:600;">Server is still busy. Please click <strong>Try Again</strong> to search when ready.</span>`;
        return;
      }

      // Check if server finished previous search before starting
      try {
        const stRes = await fetch(`${API_BASE}/search/status`);
        if (stRes.ok) {
          const st = await stRes.json();
          if (st.busy) {
            updateCountdown();
            return; // Still running, wait for next tick
          }
        }
      } catch (_) {}

      // Server is ready! Auto-retry immediately
      clearInterval(_busyCountdownTimer);
      _busyCountdownTimer = null;
      busyState.classList.add('hidden');
      loader.classList.remove('hidden');
      searchBtn.disabled = true;
      doSearch(currentPage);
      return;
    }
    updateCountdown();
  }, 1000);
}

function hideAllStates() {
  welcomeState.classList.add('hidden');
  emptyState.classList.add('hidden');
  resultsSection.classList.add('hidden');
  busyState.classList.add('hidden');
  if (_busyCountdownTimer) {
    clearInterval(_busyCountdownTimer);
    _busyCountdownTimer = null;
  }
}

// Retry button
if (retryBtn) {
  retryBtn.addEventListener('click', () => {
    if (_busyCountdownTimer) {
      clearInterval(_busyCountdownTimer);
      _busyCountdownTimer = null;
    }
    doSearch(currentPage);
  });
}

function renderResults(data) {
  if (data.total === 0 || !data.results || data.results.length === 0) {
    if (emptyTitle && emptyDesc) {
      emptyTitle.textContent = "No Records Found";
      emptyDesc.textContent = `The record "${esc(data.query)}" was not found in the database.`;
    }
    emptyState.classList.remove('hidden');
    return;
  }

  const totalCount = data.total ?? (data.results ? data.results.length : 0);
  const from = (data.page - 1) * data.limit + 1;
  const to   = Math.min(data.page * data.limit, totalCount);
  
  metaCount.textContent = `Showing ${from.toLocaleString()}–${to.toLocaleString()} of ${totalCount.toLocaleString()} records`;
  metaLatency.textContent = `${data.elapsed_ms || 0} ms`;

  resultsBody.innerHTML = '';
  (data.results || []).forEach(row => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="mobile">${esc(row.mobile)}</td>
      <td>${esc(row.name)}</td>
      <td>${esc(row.fname)}</td>
      <td>${esc(row.email)}</td>
      <td class="doc_id">${esc(row.doc_id)}</td>
      <td>${esc(row.circle)}</td>
      <td>${esc(row.alt)}</td>
      <td title="${esc(row.address)}">${esc(row.address)}</td>
    `;
    tr.addEventListener('click', () => showModal(row));
    resultsBody.appendChild(tr);
  });

  renderPagination(data.page || 1, data.pages || data.total_pages || Math.ceil(totalCount / (data.limit || 50)), totalCount);
  resultsSection.classList.remove('hidden');
}

function renderPagination(page, pages, total) {
  paginationEl.innerHTML = '';
  if (pages <= 1) return;

  const createBtn = (label, p, active = false, disabled = false) => {
    const b = document.createElement('button');
    b.innerHTML = label;
    if (active) b.classList.add('active');
    b.disabled = disabled;
    b.addEventListener('click', () => doSearch(p));
    paginationEl.appendChild(b);
  };

  createBtn('&laquo; Prev', page - 1, false, page <= 1);

  const lo = Math.max(1, page - 2);
  const hi = Math.min(pages, page + 2);

  if (lo > 1) {
    createBtn('1', 1);
    if (lo > 2) {
      const sp = document.createElement('span');
      sp.className = 'page-info';
      sp.textContent = '...';
      paginationEl.appendChild(sp);
    }
  }

  for (let p = lo; p <= hi; p++) {
    createBtn(p, p, p === page);
  }

  if (hi < pages) {
    if (hi < pages - 1) {
      const sp = document.createElement('span');
      sp.className = 'page-info';
      sp.textContent = '...';
      paginationEl.appendChild(sp);
    }
    createBtn(pages, pages);
  }

  createBtn('Next &raquo;', page + 1, false, page >= pages);

  const totalPages = pages || Math.ceil((total || 1) / 50) || 1;
  const info = document.createElement('span');
  info.className = 'page-info';
  info.textContent = `Page ${page || 1} of ${totalPages.toLocaleString()}`;
  paginationEl.appendChild(info);
}

// Modal
const LABELS = {
  mobile: 'Mobile Number',
  name: 'Full Name',
  fname: "Father's Name",
  email: 'Email Address',
  doc_id: 'Document ID (Aadhaar/DL/PAN)',
  circle: 'Telecom Circle / Operator',
  alt: 'Alternate Contact Phone',
  address: 'Residential Address',
  oid: 'MongoDB Object ID'
};

function showModal(row) {
  modalTable.innerHTML = '';
  Object.entries(row).forEach(([k, v]) => {
    if (v === null || v === undefined || v === '') return;
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${LABELS[k] || k}</td><td>${esc(v)}</td>`;
    modalTable.appendChild(tr);
  });
  modalOverlay.classList.remove('hidden');
}

closeModal.addEventListener('click', () => modalOverlay.classList.add('hidden'));
modalOverlay.addEventListener('click', (e) => {
  if (e.target === modalOverlay) modalOverlay.classList.add('hidden');
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') modalOverlay.classList.add('hidden');
});

// CSV Export
exportBtn.addEventListener('click', () => {
  if (!lastResults.length) return;
  const cols = ['mobile', 'name', 'fname', 'email', 'doc_id', 'circle', 'alt', 'address'];
  const header = cols.join(',');
  const rows = lastResults.map(r => 
    cols.map(c => `"${(r[c] || '').replace(/"/g, '""')}"`).join(',')
  );
  const csvContent = [header, ...rows].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `search_results_${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
});

function esc(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
